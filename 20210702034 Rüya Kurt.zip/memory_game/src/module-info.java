/**
 * 
 */
/**
 * 
 */
module memory_game {
	requires java.desktop;
}