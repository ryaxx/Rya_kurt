package proje212;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.*;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.Comparator;

public class Level extends JPanel {
    private int levelNumber;
    private List<Card> cards;
    private Player player;
    private int triesLeft;
    private JLabel triesLabel;
    private Timer flipBackTimer;
    private Card firstSelectedCard;
    private JFrame parentFrame;
    private static final String HIGH_SCORES_FILE = "high_scores.txt";
    private String levelInfo = "";

    public Level(int levelNumber, List<ImageIcon> images, Player player, JFrame parentFrame) {
        this.levelNumber = levelNumber;
        this.player = player;
        this.triesLeft = calculateTriesLeft(levelNumber);
        this.levelInfo = "LEVEL " + levelNumber;

        // Update the triesLabel with increased width and larger font size
        this.triesLabel = new JLabel(this.levelInfo + "    Tries Left: " + triesLeft, SwingConstants.CENTER);
        this.triesLabel.setPreferredSize(new Dimension(400, 50)); // Adjust the width and height
        this.triesLabel.setFont(new Font("Arial", Font.BOLD, 34)); // Set the font size to 18 and make it bold
        this.triesLabel.setForeground(Color.WHITE);
        this.firstSelectedCard = null;
        this.parentFrame = parentFrame;

        setLayout(new BorderLayout());

        JPanel cardPanel = createCardPanel(images);
        add(triesLabel, BorderLayout.NORTH);
        add(cardPanel, BorderLayout.CENTER);
        setupMenuBar(parentFrame);

        // Set background color based on the level
        switch (levelNumber) {
            case 1:
                setBackground(new Color(87, 159, 199)); // Light Blue
                break;
            case 2:
                setBackground(new Color(218, 112, 214)); // Medium Purple
                break;
            case 3:
                setBackground(new Color(220, 20, 60)); // Crimson
                break;
            default:
                setBackground(Color.WHITE);
                break;
        }

        flipBackTimer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firstSelectedCard.flip();
                firstSelectedCard = null;
                for (Card card : cards) {
                    if (card.isFlipped() && !card.isMatched()) {
                        card.flip();
                    }
                }
                flipBackTimer.stop();
            }
        });
    }


    private JPanel createCardPanel(List<ImageIcon> images) {
        int gridSize = 4;
        JPanel cardPanel = new JPanel(new GridLayout(gridSize, gridSize));
        Collections.shuffle(images);
        cards = new ArrayList<>();

        String basePath = "/memory_game/resources/";
        switch (levelNumber) {
            case 1:
                basePath += "Level1-InternetAssets";
                break;
            case 2:
                basePath += "Level2-CyberSecurityAssets";
                break;
            case 3:
                basePath += "Level3-GamingComputerAssets";
                break;
            default:
                basePath += "Level1-InternetAssets";
                break;
        }

        ImageIcon emptyImage = new ImageIcon(getClass().getResource(basePath + "/no_image.png"));

        for (ImageIcon image : images) {
            Card card = new Card(image, emptyImage);
            card.addActionListener(new CardClickListener());
            cards.add(card);
            cardPanel.add(card);
        }
        return cardPanel;
    }

    private int calculateTriesLeft(int levelNumber) {
        switch (levelNumber) {
            case 1:
                return 18;
            case 2:
                return 15;
            case 3:
                return 12;
            default:
                return 18;
        }
    }

    private void setupMenuBar(JFrame frame) {
        JMenuBar menuBar = new JMenuBar();

        JMenu gameMenu = new JMenu("Game");
        JMenuItem restartItem = new JMenuItem("Restart");
        JMenuItem highScoresItem = new JMenuItem("High Scores");

        restartItem.addActionListener(e -> restartLevel());
        highScoresItem.addActionListener(e -> showHighScores());

        gameMenu.add(restartItem);
        gameMenu.add(highScoresItem);

        JMenu aboutMenu = new JMenu("About");
        JMenuItem aboutGameItem = new JMenuItem("About the Game");
        JMenuItem aboutDeveloperItem = new JMenuItem("About the Developer");

        aboutGameItem.addActionListener(e -> showAboutGame());
        aboutDeveloperItem.addActionListener(e -> showAboutDeveloper());

        aboutMenu.add(aboutGameItem);
        aboutMenu.add(aboutDeveloperItem);

        JMenu exitMenu = new JMenu("Exit");

        exitMenu.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getButton() == MouseEvent.BUTTON1) {
                    System.exit(0);
                }
            }
        });

        menuBar.add(gameMenu);
        menuBar.add(aboutMenu);
        menuBar.add(exitMenu);

        frame.setJMenuBar(menuBar);
    }

    private void restartLevel() {
        parentFrame.setContentPane(new Level(levelNumber, loadImages(levelNumber), player, parentFrame));
        parentFrame.revalidate();
    }

    private void showHighScores() {
        try {
            List<String> highScores = HighScoresManager.loadHighScores();
            StringBuilder highScoresMessage = new StringBuilder("High Scores:\n");
            for (String score : highScores) {
                highScoresMessage.append(score).append("\n");
            }
            JOptionPane.showMessageDialog(this, highScoresMessage.toString(), "High Scores", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading high scores.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showAboutGame() {
        JOptionPane.showMessageDialog(this, "This is a memory card game. Match the pairs to win.", "About the Game", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showAboutDeveloper() {
        JOptionPane.showMessageDialog(this, "Developer: Rüya Kurt\nStudent ID: 20210702034", "About the Developer", JOptionPane.INFORMATION_MESSAGE);
    }

    private List<ImageIcon> loadImages(int levelNumber) {
        List<ImageIcon> images = new ArrayList<>();
        String basePath = "/memory_game/resources/";

        switch (levelNumber) {
            case 1:
                basePath += "Level1-InternetAssets/";
                break;
            case 2:
                basePath += "Level2-CyberSecurityAssets/";
                break;
            case 3:
                basePath += "Level3-GamingComputerAssets/";
                break;
            default:
                basePath += "Level1-InternetAssets/";
                break;
        }

        for (int i = 0; i < 8; i++) {
            String imagePath = basePath + i + ".png";
            ImageIcon imageIcon = new ImageIcon(getClass().getResource(imagePath));
            images.add(imageIcon);
            images.add(imageIcon);
        }

        return images;
    }

    private void checkGameOver() {
        if (triesLeft <= 0) {
            JOptionPane.showMessageDialog(this, "You lost! Final score: " + player.getScore(), "Game Over", JOptionPane.INFORMATION_MESSAGE);
            promptForHighScore();
            parentFrame.setContentPane(new Level(1, loadImages(1), player, parentFrame));
            parentFrame.revalidate();
        } else if (allCardsMatched()) {
            if (levelNumber == 3) {
                JOptionPane.showMessageDialog(this, "You won the game! Final score: " + player.getScore(), "Congratulations", JOptionPane.INFORMATION_MESSAGE);
                promptForHighScore();
            } else {
                JOptionPane.showMessageDialog(this, "Level " + levelNumber + " complete! Proceeding to next level.", "Level Complete", JOptionPane.INFORMATION_MESSAGE);
                parentFrame.setContentPane(new Level(levelNumber + 1, loadImages(levelNumber + 1), player, parentFrame));
                parentFrame.revalidate();
            }
        }
    }

    private void promptForHighScore() {
        String playerName = JOptionPane.showInputDialog(this, "Enter your name:", "Player Name", JOptionPane.PLAIN_MESSAGE);
        if (playerName == null || playerName.trim().isEmpty()) {
            playerName = "Unknown Player";
        }
        String playerID = JOptionPane.showInputDialog(this, "Enter your ID:", "Player ID", JOptionPane.PLAIN_MESSAGE);
        if (playerID == null || playerID.trim().isEmpty()) {
            playerID = "Unknown ID";
        }
        player.setName(playerName);
        player.setId(playerID);
        HighScoresManager.updateHighScores(playerName, player.getScore(), playerID);
    }

    private boolean allCardsMatched() {
        for (Card card : cards) {
            if (!card.isMatched()) {
                return false;
            }
        }
        return true;
    }

    private class CardClickListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            Card clickedCard = (Card) e.getSource();
            if (clickedCard.isFlipped() || clickedCard.isMatched() || flipBackTimer.isRunning()) {
                return;
            }

            clickedCard.flip();

            if (firstSelectedCard == null) {
                firstSelectedCard = clickedCard;
            } else {
                if (firstSelectedCard.getIcon().equals(clickedCard.getIcon())) {
                    firstSelectedCard.setMatched(true);
                    clickedCard.setMatched(true);
                    player.addScore(levelNumber, true);
                    firstSelectedCard = null;
                    checkGameOver();
                } else {
                    flipBackTimer.start();
                    triesLeft--;
                    player.addScore(levelNumber, false);
                    triesLabel.setText(levelInfo + "  Tries Left: " + triesLeft);
                    checkGameOver();

                    if (levelNumber == 3) {
                        shuffleCards();
                    }
                }
            }
        }
    }

    private void shuffleCards() { 
        List<Card> unmatchedCards = cards.stream()
                .filter(card -> !card.isMatched())
                .collect(Collectors.toList());

        List<ImageIcon> frontImages = unmatchedCards.stream()
                .map(Card::getFrontImage)
                .collect(Collectors.toList());

        Collections.shuffle(frontImages);

        for (int i = 0; i < unmatchedCards.size(); i++) {
            Card currentCard = unmatchedCards.get(i);
            currentCard.setFrontImage(frontImages.get(i));
        }
    }
}
