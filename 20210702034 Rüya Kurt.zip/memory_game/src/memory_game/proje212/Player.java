package proje212;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Player {
    private String name;
    private String id;
    private int score;

    public Player(String name) {
        this.name = name;
        this.score = 0;
    }

    public void addScore(int level, boolean isMatch) {
        if (isMatch) {
            switch (level) {
                case 1:
                    score += 5;
                    break;
                case 2:
                    score += 4;
                    break;
                case 3:
                    score += 3;
                    break;
            }
        } else {
            switch (level) {
                case 1:
                    score -= 1;
                    break;
                case 2:
                    score -= 2;
                    break;
                case 3:
                    score -= 3;
                    break;
            }
        }
    }

    public int getScore() {
        return score;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void saveScore() {
        String desktopPath = System.getProperty("user.home") + "/Desktop/";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(desktopPath + "high_scores.txt", true))) {
            writer.write(name + ": " + score);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<String> loadHighScores() {
        List<String> highScores = new ArrayList<>();
        String desktopPath = System.getProperty("user.home") + "/Desktop/";
        try (BufferedReader reader = new BufferedReader(new FileReader(desktopPath + "high_scores.txt"))) {
            String line;
            int count = 0;
            while ((line = reader.readLine()) != null && count < 10) {
                highScores.add(line);
                count++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return highScores;
    }
}
