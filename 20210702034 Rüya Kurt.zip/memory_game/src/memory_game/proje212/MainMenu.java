package proje212;

import javax.swing.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenu extends JFrame {
    public MainMenu() {
        setTitle("Flash Cards Game");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel contentPane = new JPanel(null);
        setContentPane(contentPane);

     // Background image
        ImageIcon backgroundImage = new ImageIcon(getClass().getResource("/memory_game/resources/background.jpg"));
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setBounds(0, 0, 600, 400);

        // Title label
        JLabel titleLabel = new JLabel("Memory Card Game");
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBounds(150, 40, 300, 40); // Centered horizontally
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.ITALIC, 24));
        titleLabel.setForeground(new Color(173, 216, 230)); 
        contentPane.add(titleLabel);

        // Buttons
        JButton startButton = new JButton("Start Game");
        JButton selectLevelButton = new JButton("Select Level");
        JButton instructionsButton = new JButton("Instructions");
        JButton exitButton = new JButton("Exit");

        // Center buttons horizontally
        startButton.setBounds(225, 100, 150, 30);
        selectLevelButton.setBounds(225, 150, 150, 30);
        instructionsButton.setBounds(225, 200, 150, 30);
        exitButton.setBounds(225, 250, 150, 30);

      
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new game(1).setVisible(true);
                dispose();
            }
        });

        selectLevelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] options = {"Level 1", "Level 2", "Level 3"};
                ImageIcon icon = new ImageIcon(getClass().getResource("/memory_game/resources/swingIcon.png"));
                int choice = JOptionPane.showOptionDialog(null, "Select Level",
                        "Level Selection", JOptionPane.DEFAULT_OPTION,
                        JOptionPane.INFORMATION_MESSAGE, icon, options, options[0]);
                if (choice != JOptionPane.CLOSED_OPTION) {
                    new game(choice + 1).setVisible(true);
                    dispose();
                }
            }
        });


        instructionsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Instructions instructions = new Instructions();
                instructions.setVisible(true);
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        contentPane.add(startButton);
        contentPane.add(selectLevelButton);
        contentPane.add(instructionsButton);
        contentPane.add(exitButton);
        contentPane.add(backgroundLabel);
        contentPane.setComponentZOrder(backgroundLabel, contentPane.getComponentCount() - 1);

        // Center the frame on the screen
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MainMenu().setVisible(true);
            }
        });
    }
}
