package proje212;

import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class HighScoresManager {
    private static final String HIGH_SCORES_FILE = "high_scores.txt";

    public static void updateHighScores(String playerName, int score, String playerID) {
        try {
            List<String> highScores = loadHighScores();
            highScores.add(playerName + " (" + playerID + "): " + score);
            highScores.sort(Comparator.comparingInt(HighScoresManager::extractScore).reversed());
            if (highScores.size() > 10) {
                highScores = highScores.subList(0, 10);
            }
            saveHighScores(highScores);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static int extractScore(String scoreEntry) {
        return Integer.parseInt(scoreEntry.split(": ")[1]);
    }

    public static List<String> loadHighScores() throws IOException {
        List<String> highScores = new ArrayList<>();
        File file = new File(HIGH_SCORES_FILE);
        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    highScores.add(line);
                }
            }
        }
        return highScores;
    }

    private static void saveHighScores(List<String> highScores) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(HIGH_SCORES_FILE))) {
            for (String score : highScores) {
                writer.write(score);
                writer.newLine();
            }
        }
    }
}
