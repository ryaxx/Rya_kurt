package proje212;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class game extends JFrame {
    private Player player;
    private Level currentLevel;
    private JFrame mainMenu;

    public game(int levelNumber) {
        setTitle("Flash Cards Game ");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  // This will center the window on the screen

        player = new Player("Player");
        List<ImageIcon> images = loadImages(levelNumber);
        currentLevel = new Level(levelNumber, images, player, this);
        add(currentLevel);
    } 

    private List<ImageIcon> loadImages(int levelNumber) {
        List<ImageIcon> images = new ArrayList<>();
        String basePath = "/memory_game/resources/";

        switch (levelNumber) {
            case 1:
                basePath += "Level1-InternetAssets/";
                break;
            case 2:
                basePath += "Level2-CyberSecurityAssets/";
                break;
            case 3:
                basePath += "Level3-GamingComputerAssets/";
                break;
            default:
                basePath += "Level1-InternetAssets/";
                break;
        }

        for (int i = 0; i < 8; i++) {
            String imagePath = basePath + i + ".png";
            ImageIcon imageIcon = new ImageIcon(getClass().getResource(imagePath));
            images.add(imageIcon);
            images.add(imageIcon); 
        }

        return images;
    }

    public void startGame(int levelNumber) {
        setTitle("Memory Card Game - Level " + levelNumber);
        currentLevel.removeAll();
        List<ImageIcon> images = loadImages(levelNumber);
        currentLevel = new Level(levelNumber, images, player, this);
        setContentPane(currentLevel);
        revalidate();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            game game = new game(1);
            game.setVisible(true);
        });
    }
}
