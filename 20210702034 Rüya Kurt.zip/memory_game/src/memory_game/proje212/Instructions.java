package proje212;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Instructions extends JFrame {
    public Instructions() {
        setTitle("Message");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create a panel to hold the text area and the icon
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE); // Set the background color of the main panel to white

        // Create the text area for the instructions
        JTextArea textArea = new JTextArea("Instructions:\n" +
                "1. Flip two cards to find a match.\n" +
                "2. If you find a match, you get points.\n" +
                "3. If not, tries left decreases.\n" +
                "4. Complete the level before running out of tries.");
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);
        textArea.setEditable(false);
        textArea.setFont(new Font("Arial", Font.PLAIN, 14));
        textArea.setMargin(new Insets(10, 10, 10, 10));
        textArea.setBackground(Color.WHITE); // Set background color to white

        // Create a label with an icon
        ImageIcon icon = new ImageIcon(getClass().getResource("/memory_game/resources/swingIcon.png"));
        JLabel iconLabel = new JLabel(icon);
        iconLabel.setVerticalAlignment(SwingConstants.TOP); // Align icon to the top

        // Create a panel to hold the icon and text area side by side
        JPanel textPanel = new JPanel(new BorderLayout());
        textPanel.setBackground(Color.WHITE); // Set the background color of the text panel to white
        textPanel.add(iconLabel, BorderLayout.WEST);
        textPanel.add(textArea, BorderLayout.CENTER); // Directly add textArea without JScrollPane

        panel.add(textPanel, BorderLayout.CENTER);

        // Create an OK button
        JButton okButton = new JButton("OK");
        okButton.setPreferredSize(new Dimension(80, 30));
        okButton.setBackground(Color.WHITE);
        okButton.setForeground(Color.BLACK);

        // Add hover and click effects to the OK button
        okButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                okButton.setBackground(new Color(128, 0, 128)); // Purple color on hover
                okButton.setForeground(Color.WHITE);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                okButton.setBackground(Color.LIGHT_GRAY); // Default color when not hovered
                okButton.setForeground(Color.BLACK);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                okButton.setBackground(new Color(75, 0, 130)); // Darker purple color on click
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                okButton.setBackground(new Color(128, 0, 128)); // Purple color on release
            }
        });

        okButton.addActionListener(e -> dispose());

        // Create a panel for the button and align it to the right
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(Color.WHITE); // Set the background color of the button panel to white
        buttonPanel.add(okButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        // Add the panel to the frame
        add(panel);

        // Center the frame on the screen
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Instructions instructions = new Instructions();
            instructions.setVisible(true);
        });
    }
}
