 package proje212;

import javax.swing.*;
import java.awt.*;

public class Card extends JButton {
    private ImageIcon frontImage;
	private ImageIcon backImage;
    private boolean isFlipped;
    private boolean isMatched;

    public Card(ImageIcon frontImage, ImageIcon backImage) {
        this.frontImage = frontImage;
        this.backImage = backImage;
        this.isFlipped = false;
        this.isMatched = false;
        setIcon(backImage);
        setPreferredSize(new Dimension(100, 100));
    }

    public void flip() {
        if (isFlipped) {
            setIcon(backImage);
        } else {
            setIcon(frontImage);
        }
        isFlipped = !isFlipped;
    }

    public boolean isFlipped() {
        return isFlipped;
    }

    public boolean isMatched() {
        return isMatched;
    }

    public void setMatched(boolean matched) {
        isMatched = matched;
    }
    
    public ImageIcon getFrontImage() {
		return frontImage;
	}

	public void setFrontImage(ImageIcon frontImage) {
		this.frontImage = frontImage;
	}
}
